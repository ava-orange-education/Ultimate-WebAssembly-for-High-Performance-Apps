# Chapter 10 — WASI (WebAssembly System Interface) — Executable Code Kit

This zip provides **runnable projects** that match Chapter 10 topics (WASI API basics, file I/O, env/args, clocks/random, and running in different environments). fileciteturn7file0

Included demos:
1) **Rust WASI CLI**: args + env + time + random + file read/write
2) **C WASI CLI**: file read/write + env + proc_exit
3) **Node.js WASI host**: run a WASI module from Node (experimental API)
4) Optional helpers + sample files

---

## Prerequisites

- Rust stable
- Wasmtime (recommended runtime)
- (Optional) clang for C + WASI SDK
- Node.js 18+ (Node WASI host demo)

### Install Wasmtime
```bash
curl https://wasmtime.dev/install.sh -sSf | bash
```

### Rust target for WASI
```bash
rustup target add wasm32-wasi
```

---

# 1) Rust WASI CLI demo

Folder: `rust-wasi-cli/`

## Build
```bash
cd rust-wasi-cli
cargo build --release --target wasm32-wasi
```

## Run with capabilities
From `rust-wasi-cli/`:

- Allow access to `./data` as `/data` inside the module
- Pass an env var and args

```bash
wasmtime run   --dir=./data::/data   --env APP_MODE=dev   target/wasm32-wasi/release/rust_wasi_cli.wasm   --input /data/input.txt --output /data/output.txt
```

Expected:
- Prints args + env
- Prints current time (clock)
- Generates random bytes
- Reads input file, writes output file

---

# 2) C WASI CLI demo

Folder: `c-wasi-cli/`

This uses the **WASI SDK** (clang + sysroot).

## Install WASI SDK
Download the WASI SDK release for your OS from GitHub releases, then set:
- `WASI_SDK_PATH` to the folder containing `bin/clang`

Example:
```bash
export WASI_SDK_PATH=$HOME/wasi-sdk
```

## Build
```bash
cd c-wasi-cli
./build.sh
```

## Run
```bash
wasmtime run --dir=./data::/data c_wasi_cli.wasm /data/input.txt /data/output.txt
```

---

# 3) Node.js WASI host demo (runs a WASI module from Node)

Folder: `node-wasi-host/`

This demonstrates running a WASI module from Node’s `wasi` API (still experimental in Node).

## Run
```bash
cd node-wasi-host
npm install
npm run run
```

By default, it runs the prebuilt Rust WASI module from:
- `../rust-wasi-cli/target/wasm32-wasi/release/rust_wasi_cli.wasm`

If you haven’t built it yet, build the Rust demo first (Section 1).

---

# 4) Sample data

Folder: `data/`
- `input.txt` is used by both Rust and C demos.
- output files will be written next to it when you run examples.

---

## Notes on WASI permissions (capability-based security)

WASI modules can only access resources explicitly granted:
- `--dir=...` for filesystem
- `--env KEY=VALUE` for environment variables
- networking is proposal-based (`wasi-sockets`) and runtime-dependent (not standardized in snapshot preview1)

---

## Cleanup

Just delete generated output files under `data/` and build artifacts under project folders.
