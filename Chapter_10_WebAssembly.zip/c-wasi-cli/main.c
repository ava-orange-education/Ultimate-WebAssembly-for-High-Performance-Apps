\
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Simple WASI-friendly file copy + uppercase transform.
// Args: input_path output_path
int main(int argc, char** argv) {
    if (argc < 3) {
        fprintf(stderr, "Usage: c_wasi_cli.wasm <input> <output>\n");
        return 2;
    }

    const char* input = argv[1];
    const char* output = argv[2];

    const char* mode = getenv("APP_MODE");
    if (mode) {
        printf("APP_MODE=%s\n", mode);
    } else {
        printf("APP_MODE not set\n");
    }

    FILE* fin = fopen(input, "rb");
    if (!fin) {
        fprintf(stderr, "Failed to open input: %s\n", input);
        return 1;
    }

    FILE* fout = fopen(output, "wb");
    if (!fout) {
        fprintf(stderr, "Failed to open output: %s\n", output);
        fclose(fin);
        return 1;
    }

    int c;
    while ((c = fgetc(fin)) != EOF) {
        if (c >= 'a' && c <= 'z') c = c - 32;
        fputc(c, fout);
    }

    fclose(fin);
    fclose(fout);
    printf("Wrote output to %s\n", output);
    return 0;
}
