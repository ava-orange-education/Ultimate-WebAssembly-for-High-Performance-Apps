import init, {
  add,
  reverse_string,
  capitalize,
  Point,
  sum,
  get_user,
  log_data,
} from "../wasm-utils/pkg/wasm_utils.js";

const outEl = document.getElementById("out");

function println(s) {
  outEl.textContent += s + "\n";
}

async function run() {
  outEl.textContent = "";
  await init();

  println("add(2, 3) = " + add(2, 3));
  println('reverse_string("hello") = ' + reverse_string("hello"));
  println('capitalize("rust") = ' + capitalize("rust"));

  const p1 = new Point(0, 0);
  const p2 = new Point(3, 4);
  println(`Point p1=(${p1.x()},${p1.y()}), p2=(${p2.x()},${p2.y()})`);
  println("p1.distance(p2) = " + p1.distance(p2));

  const arr = new Int32Array([10, 20, 30]);
  println("sum([10,20,30]) = " + sum(arr));

  const user = get_user();
  println("get_user() = " + JSON.stringify(user));

  log_data(42);
  console.log("All done!");
}

run().catch((e) => {
  console.error(e);
  outEl.textContent = "Error: " + (e?.stack || e?.message || String(e));
});
