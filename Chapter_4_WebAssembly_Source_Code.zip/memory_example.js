const memory = new WebAssembly.Memory({ initial: 1 });
const buffer = new Uint8Array(memory.buffer);
buffer[0] = 255;
console.log("Memory value:", buffer[0]);