import init, { reverse } from './pkg/module.js';

init().then(() => {
  console.log(reverse('WebAssembly')); // Outputs "ylbmessAbeW"
});