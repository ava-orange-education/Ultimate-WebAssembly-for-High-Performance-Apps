export function captureError(err) {
  console.error("[monitor] captured error:", err);
  // Example (replace with your collector):
  // fetch("/api/wasm-errors", { method: "POST", body: JSON.stringify({ message: err.message }) });
}

export function captureMetric(name, value) {
  console.log("[monitor] metric:", name, value);
}
