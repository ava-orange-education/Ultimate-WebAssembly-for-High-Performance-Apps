const wasm = require("../rust-wasm/pkg/rust_wasm_integration.js");

describe("JS ↔ WASM integration", () => {
  test("add should work", () => {
    expect(wasm.add(2, 3)).toBe(5);
  });

  test("validate_email should work", () => {
    expect(wasm.validate_email("test@example.com")).toBe(true);
    expect(wasm.validate_email("invalid-email")).toBe(false);
  });
});
