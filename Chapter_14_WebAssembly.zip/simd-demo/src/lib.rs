
use wasm_bindgen::prelude::*;
use std::arch::wasm32::*;

#[wasm_bindgen]
pub fn add_vectors(a: &[f32], b: &[f32]) -> Vec<f32> {
    let mut result = Vec::with_capacity(a.len());
    let mut i = 0;

    while i + 4 <= a.len() {
        unsafe {
            let av = f32x4_load(a.as_ptr().add(i));
            let bv = f32x4_load(b.as_ptr().add(i));
            let rv = f32x4_add(av, bv);
            let mut temp = [0.0; 4];
            f32x4_store(temp.as_mut_ptr(), rv);
            result.extend_from_slice(&temp);
        }
        i += 4;
    }

    while i < a.len() {
        result.push(a[i] + b[i]);
        i += 1;
    }

    result
}
