# Node.js WASI host demo

Run:
```bash
npm install
npm run run
```

If you want to point to a different WASM module:
```bash
WASM_PATH=/absolute/path/to/module.wasm npm run run
```
