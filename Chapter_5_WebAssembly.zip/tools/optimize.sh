#!/usr/bin/env bash
set -euo pipefail

PKG_DIR="$(cd "$(dirname "$0")/../wasm-perf/pkg" && pwd)"
IN_WASM="$PKG_DIR/wasm_perf_bg.wasm"
OUT_WASM="$PKG_DIR/wasm_perf_bg.opt.wasm"

if [ ! -f "$IN_WASM" ]; then
  echo "Missing $IN_WASM"
  echo "Build first: (cd wasm-perf && wasm-pack build --target web --release)"
  exit 1
fi

if ! command -v wasm-opt >/dev/null 2>&1; then
  echo "wasm-opt not found. Install Binaryen to use this script."
  exit 1
fi

echo "Input wasm:  $IN_WASM"
echo "Output wasm: $OUT_WASM"

echo "Running wasm-opt -O3..."
wasm-opt -O3 "$IN_WASM" -o "$OUT_WASM"

echo
echo "Size report:"
ls -lh "$IN_WASM" "$OUT_WASM"

if command -v brotli >/dev/null 2>&1; then
  echo
  echo "Creating Brotli-compressed outputs..."
  brotli -Z -f "$IN_WASM" -o "$IN_WASM.br"
  brotli -Z -f "$OUT_WASM" -o "$OUT_WASM.br"
  ls -lh "$IN_WASM.br" "$OUT_WASM.br"
else
  echo
  echo "brotli not found; skipping .br generation."
fi

echo
echo "Done ✅"
