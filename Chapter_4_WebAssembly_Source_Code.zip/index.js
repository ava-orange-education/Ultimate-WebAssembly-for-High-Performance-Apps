import init, { multiply, greet } from './pkg/module.js';

init().then(() => {
  console.log("Multiply:", multiply(5, 10));
  console.log(greet("WebAssembly"));
});