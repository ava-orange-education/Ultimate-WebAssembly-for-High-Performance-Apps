-- Conceptual example from Chapter 11
-- Requires pg-wasm or custom PostgreSQL build

-- CREATE FUNCTION rust_add(a INT, b INT)
-- RETURNS INT
-- AS 'file:///modules/rust_add.wasm'
-- LANGUAGE wasm;
