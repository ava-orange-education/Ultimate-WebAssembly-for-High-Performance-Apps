
import init, { add_vectors } from "../pkg/simd_demo.js";

await init();

const a = new Float32Array([1,2,3,4,5,6,7,8]);
const b = new Float32Array([8,7,6,5,4,3,2,1]);

document.getElementById("out").textContent =
  JSON.stringify(add_vectors(a, b), null, 2);
