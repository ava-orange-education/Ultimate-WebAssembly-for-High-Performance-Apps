# Prebuilt WASM artifacts

To keep this zip lightweight and dependency-free, the actual `.wasm` binary is not included here.

Generate it locally:
```bash
cd ../rust/wasm_math
wasm-pack build --target web --release --out-dir ../../pkg --out-name wasm_math
```

After build, you'll see:
- `wasm_math.js`
- `wasm_math_bg.wasm`

Both the **web demo** and **React Native WebView demo** will work after that.
