import init, { heavy_compute, may_fail } from "../../rust/pkg/instrumentation_wasm.js";

const app = document.getElementById("app");
app.innerHTML = `
  <div style="max-width: 920px; margin: 40px auto; font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;">
    <h1>Instrumentation + Monitoring Hooks</h1>
    <p>Open DevTools Console to see Rust-side logs. This also measures duration in JS.</p>

    <div style="padding: 16px; border: 1px solid #ddd; border-radius: 12px;">
      <label>Work (n): <input id="n" type="number" value="250000" /></label>
      <button id="run">Run heavy_compute</button>
      <button id="fail">Call may_fail(-1)</button>
      <pre id="out" style="margin-top: 12px; white-space: pre-wrap;"></pre>
    </div>
  </div>
`;

await init();

const out = document.getElementById("out");
const nEl = document.getElementById("n");

document.getElementById("run").addEventListener("click", () => {
  const n = Number(nEl.value);
  const t0 = performance.now();
  const result = heavy_compute(n);
  const dt = performance.now() - t0;

  out.textContent = JSON.stringify({ result, duration_ms: dt }, null, 2);
});

document.getElementById("fail").addEventListener("click", async () => {
  try {
    // wasm-bindgen throws JS Error for Err(JsValue)
    may_fail(-1);
    out.textContent = "Unexpected success";
  } catch (e) {
    const { captureError } = await import("./monitor.js");
    captureError(e);
    out.textContent = `Captured error: ${e?.message ?? String(e)}`;
  }
});
