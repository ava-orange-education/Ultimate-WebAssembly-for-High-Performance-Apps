# C WASI CLI demo

## Build
1) Install wasi-sdk, then:
```bash
export WASI_SDK_PATH=/path/to/wasi-sdk
```

2) Build:
```bash
./build.sh
```

## Run
```bash
wasmtime run --dir=./data::/data --env APP_MODE=dev c_wasi_cli.wasm /data/input.txt /data/output_c.txt
```
