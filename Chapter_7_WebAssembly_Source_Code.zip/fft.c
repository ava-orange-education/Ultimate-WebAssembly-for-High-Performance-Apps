
#include <stdio.h>
#include <math.h>

#define PI 3.14159265358979323846

void fft(double *x, double *y, int n) {
    if (n <= 1) return;

    double even_x[n/2], even_y[n/2], odd_x[n/2], odd_y[n/2];
    for (int i = 0; i < n/2; i++) {
        even_x[i] = x[i*2];
        even_y[i] = y[i*2];
        odd_x[i] = x[i*2+1];
        odd_y[i] = y[i*2+1];
    }

    fft(even_x, even_y, n/2);
    fft(odd_x, odd_y, n/2);

    for (int k = 0; k < n/2; k++) {
        double t_real = cos(-2 * PI * k / n) * odd_x[k] - sin(-2 * PI * k / n) * odd_y[k];
        double t_imag = sin(-2 * PI * k / n) * odd_x[k] + cos(-2 * PI * k / n) * odd_y[k];
        x[k] = even_x[k] + t_real;
        y[k] = even_y[k] + t_imag;
        x[k + n/2] = even_x[k] - t_real;
        y[k + n/2] = even_y[k] - t_imag;
    }
}

int main() {
    double x[4] = {1.0, 2.0, 3.0, 4.0};
    double y[4] = {0.0, 0.0, 0.0, 0.0};

    fft(x, y, 4);

    for (int i = 0; i < 4; i++) {
        printf("(%f, %f)\n", x[i], y[i]);
    }
    return 0;
}
