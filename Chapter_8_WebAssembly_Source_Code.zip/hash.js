const wasm = await import('./pkg/hash_service.js');
await wasm.default();
console.log(wasm.hash_string("hello"));