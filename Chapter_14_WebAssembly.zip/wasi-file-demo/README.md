
# WASI File Access Demo

Demonstrates WebAssembly running as a **standalone app** using WASI.

## Run
```
rustc --target wasm32-wasi main.rs -o read_file.wasm
wasmtime run --dir=. read_file.wasm
```
