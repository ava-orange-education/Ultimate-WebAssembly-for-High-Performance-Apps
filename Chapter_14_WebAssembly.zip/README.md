
# Chapter 14 – Future Trends in WebAssembly (Runnable Demos)

This zip contains **two minimal, runnable demos** aligned with Chapter 14 concepts:

1. **WASI Standalone App** – WebAssembly beyond the browser
2. **SIMD Demo (Rust → WASM)** – Performance-oriented future WASM features

---

## Prerequisites

- Node.js 18+ (only for dev convenience)
- Rust (stable)
- wasm-pack
- Wasmtime (for WASI execution)

Install helpers:
```
rustup target add wasm32-wasi wasm32-unknown-unknown
cargo install wasm-pack
curl https://wasmtime.dev/install.sh -sSf | bash
```

---

## 1) WASI Standalone Demo

Folder: `wasi-file-demo/`

### Build
```
cd wasi-file-demo
rustc --target wasm32-wasi main.rs -o read_file.wasm
```

### Run
```
wasmtime run --dir=. read_file.wasm
```

This demonstrates **WebAssembly beyond the browser** using WASI.

---

## 2) SIMD Demo (Rust → WebAssembly)

Folder: `simd-demo/`

### Build
```
cd simd-demo
wasm-pack build --target web
```

### Run
```
cd web
npm install
npm run dev
```

Open the local URL printed by Vite.

---

## Notes

- Threading and GC are evolving specs; SIMD is already stable in modern runtimes.
- These demos are intentionally small and educational.
