use wasm_bindgen::prelude::*;
use web_sys::{console, window};

#[wasm_bindgen]
pub fn heavy_compute(n: u32) -> u32 {
    #[cfg(feature = "instrument")]
    console::log_1(&JsValue::from_str("heavy_compute() called"));

    let mut acc: u32 = 0;
    for i in 0..n {
        acc = acc.wrapping_add(i.rotate_left((i % 31) + 1));
    }

    #[cfg(feature = "instrument")]
    {
        if let Some(w) = window() {
            if let Some(p) = w.performance() {
                console::log_1(&JsValue::from_str(&format!("perf.now(): {}", p.now())));
            }
        }
    }

    acc
}

#[wasm_bindgen]
pub fn may_fail(input: i32) -> Result<i32, JsValue> {
    if input < 0 {
        return Err(js_sys::Error::new("input must be >= 0").into());
    }
    Ok(input * 2)
}
