# Chapter 6 — Rust for WebAssembly Development (Executable Code Kit)

This repo turns the Chapter 6 examples (Rust + wasm-bindgen + wasm-pack + JS integration) into a **runnable project**. fileciteturn9file0

## What you get
- `wasm-utils/` — Rust library compiled to WebAssembly using **wasm-pack**
  - `add(a,b)`
  - `reverse_string(s)`
  - `capitalize(s)`
  - `Point` struct + `distance()`
  - `sum(Int32Array)`
  - `get_user()` returning JSON via `JsValue` (Serde)
- `web-demo/` — A tiny **Vite** app that imports the generated wasm package and runs the functions in the browser
- Debug-friendly build tips (source maps)

---

## Prerequisites
- Rust stable
- wasm-pack
- Node.js 18+

Install wasm-pack:
```bash
cargo install wasm-pack
```

---

## 1) Build the Rust → Wasm package

```bash
cd wasm-utils
wasm-pack build --target web --dev
```

This creates `wasm-utils/pkg/` (JS glue + .wasm).

---

## 2) Run the web demo (browser)

```bash
cd ../web-demo
npm install
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173).

You’ll see results printed on the page (and in the browser console).

---

## 3) Production build

```bash
cd wasm-utils
wasm-pack build --target web --release

cd ../web-demo
npm run build
npm run preview
```

---

## Debugging tips
- Use `--dev` to keep debug symbols and source maps: `wasm-pack build --dev`
- In Chrome DevTools:
  - open **Sources**
  - look for `webpack://` / `wasm://` mappings (depends on bundler)
- Add logs from Rust using `web_sys::console` (see `wasm-utils/src/lib.rs`).

---

## Folder structure
```
chapter6_rust_wasm_executable/
├─ wasm-utils/        # Rust wasm-bindgen library (wasm-pack)
└─ web-demo/          # Vite app importing wasm-utils/pkg
```
