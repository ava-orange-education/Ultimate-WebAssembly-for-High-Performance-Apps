# wasm-perf (Rust + wasm-bindgen)

Build release:
```bash
wasm-pack build --target web --release
```

Build dev (for easier debugging):
```bash
wasm-pack build --target web --dev
```
