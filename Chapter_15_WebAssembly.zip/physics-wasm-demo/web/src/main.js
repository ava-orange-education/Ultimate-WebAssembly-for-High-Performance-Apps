import init, { PhysicsEngine } from "../../rust/physics-engine/pkg/physics_engine.js";

const app = document.getElementById("app");

app.innerHTML = `
  <div style="max-width: 900px; margin: 40px auto; font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;">
    <h1>Rust → WASM Physics (Sphere Collision)</h1>
    <p>
      Build the WASM first using <code>wasm-pack</code> in <code>physics-wasm-demo/rust/physics-engine</code>,
      then run this Vite app.
    </p>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; padding: 16px; border: 1px solid #ddd; border-radius: 10px;">
      <div>
        <label>Sphere A X: <input id="ax" type="number" step="0.1" value="0" /></label><br/>
        <label>Sphere A Radius: <input id="ar" type="number" step="0.1" value="1" /></label>
      </div>
      <div>
        <label>Sphere B X: <input id="bx" type="number" step="0.1" value="1.5" /></label><br/>
        <label>Sphere B Radius: <input id="br" type="number" step="0.1" value="1" /></label>
      </div>
      <div style="grid-column: 1 / -1;">
        <button id="run">Check Collision</button>
        <div id="out" style="margin-top: 10px; white-space: pre-wrap;"></div>
      </div>
    </div>
  </div>
`;

const out = document.getElementById("out");

async function main() {
  await init();

  const run = () => {
    const ax = parseFloat(document.getElementById("ax").value);
    const ar = parseFloat(document.getElementById("ar").value);
    const bx = parseFloat(document.getElementById("bx").value);
    const br = parseFloat(document.getElementById("br").value);

    const e = new PhysicsEngine();
    e.add_sphere(ax, 0, 0, ar);
    e.add_sphere(bx, 0, 0, br);

    const collisions = e.detect_collisions();
    out.textContent = JSON.stringify(
      { collisions: [collisions[0] === 1, collisions[1] === 1] },
      null,
      2
    );
  };

  document.getElementById("run").addEventListener("click", run);
  run();
}

main().catch((e) => {
  out.textContent = `Failed to init WASM. Did you run wasm-pack build?

${e?.message ?? String(e)}`;
});
