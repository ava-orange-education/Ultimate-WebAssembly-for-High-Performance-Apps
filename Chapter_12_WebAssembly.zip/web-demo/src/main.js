import init, { add, fib } from "../../shared-wasm/pkg/wasm_math.js";

const app = document.getElementById("app");
app.innerHTML = `
  <div style="max-width: 900px; margin: 40px auto; font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;">
    <h1>Chapter 12 — WebAssembly in Mobile Apps (Web Demo)</h1>
    <p>This web demo imports the same Rust→WASM module used in the React Native WebView demo.</p>

    <div style="padding: 16px; border: 1px solid #ddd; border-radius: 12px;">
      <div style="display:flex; gap:10px; flex-wrap: wrap;">
        <label>A: <input id="a" type="number" value="2" /></label>
        <label>B: <input id="b" type="number" value="3" /></label>
        <button id="btnAdd">WASM add(a,b)</button>
      </div>

      <div style="margin-top: 10px; display:flex; gap:10px; flex-wrap: wrap;">
        <label>n: <input id="n" type="number" value="35" /></label>
        <button id="btnFib">WASM fib(n) + timing</button>
      </div>

      <pre id="out" style="margin-top: 12px; white-space: pre-wrap;"></pre>
    </div>

    <hr style="margin: 24px 0;" />
    <p><strong>If you see an import error:</strong> build the WASM first:</p>
    <pre style="background:#f7f7f7; padding:12px; border-radius:12px; overflow:auto;"><code>cd shared-wasm/rust/wasm_math
wasm-pack build --target web --release --out-dir ../../pkg --out-name wasm_math</code></pre>
  </div>
`;

const out = document.getElementById("out");

async function main() {
  await init();

  document.getElementById("btnAdd").onclick = () => {
    const a = Number(document.getElementById("a").value);
    const b = Number(document.getElementById("b").value);
    out.textContent = JSON.stringify({ add: add(a, b) }, null, 2);
  };

  document.getElementById("btnFib").onclick = () => {
    const n = Number(document.getElementById("n").value);
    const t0 = performance.now();
    const res = fib(n);
    const dt = performance.now() - t0;
    out.textContent = JSON.stringify({ n, fib: res, duration_ms: dt }, null, 2);
  };
}

main().catch((e) => {
  out.textContent = `Failed to load WASM. Build it first.\n\n${e?.message ?? String(e)}`;
});
