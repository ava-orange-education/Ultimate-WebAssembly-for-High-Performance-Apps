# Jest Integration Test (JS ↔ WASM)

This demo compiles a Rust library to WASM (nodejs target) and calls it from Jest tests.

## Run
```bash
npm install
npm run build:wasm
npm test
```

## Notes
- `build:wasm` produces `rust-wasm/pkg/` which Jest imports.
