use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub struct Sphere {
    x: f32,
    y: f32,
    z: f32,
    radius: f32,
}

#[wasm_bindgen]
pub struct PhysicsEngine {
    spheres: Vec<Sphere>,
}

#[wasm_bindgen]
impl PhysicsEngine {
    #[wasm_bindgen(constructor)]
    pub fn new() -> PhysicsEngine {
        PhysicsEngine { spheres: Vec::new() }
    }

    pub fn add_sphere(&mut self, x: f32, y: f32, z: f32, radius: f32) {
        self.spheres.push(Sphere { x, y, z, radius });
    }

    pub fn detect_collisions(&self) -> Vec<u8> {
        let n = self.spheres.len();
        let mut collisions = vec![0u8; n];
        for i in 0..n {
            for j in (i + 1)..n {
                let s1 = &self.spheres[i];
                let s2 = &self.spheres[j];
                let dx = s1.x - s2.x;
                let dy = s1.y - s2.y;
                let dz = s1.z - s2.z;
                let distance = (dx * dx + dy * dy + dz * dz).sqrt();
                if distance < (s1.radius + s2.radius) {
                    collisions[i] = 1;
                    collisions[j] = 1;
                }
            }
        }
        collisions
    }
}
