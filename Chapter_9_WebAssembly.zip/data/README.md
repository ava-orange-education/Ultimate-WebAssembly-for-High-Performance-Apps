Simulated sensor data is generated at runtime.
