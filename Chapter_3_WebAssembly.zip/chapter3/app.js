async function runAll() {
    const output = document.getElementById('output');
    
    fetch('math.wasm')
        .then(response => response.arrayBuffer())
        .then(bytes => WebAssembly.instantiate(bytes, { env: { log: console.log } }))
        .then(result => {
            const { add } = result.instance.exports;
            output.textContent += `Add: ${add(3, 4)}\n`;
        });

    WebAssembly.instantiateStreaming(fetch('math.wasm'), { env: { log: console.log } })
        .then(result => {
            const { multiply } = result.instance.exports;
            output.textContent += `Multiply: ${multiply(5, 6)}\n`;
        });

    const { instance: crypto } = await WebAssembly.instantiateStreaming(fetch('crypto.wasm'));
    output.textContent += `SHA256: ${crypto.exports.sha256('data')}\n`;

    try {
        const { instance } = await WebAssembly.instantiateStreaming(fetch('compute.wasm'));
        instance.exports.run();
        output.textContent += "Compute ran successfully\n";
    } catch (err) {
        output.textContent += `Compute failed: ${err}\n`;
    }
}
