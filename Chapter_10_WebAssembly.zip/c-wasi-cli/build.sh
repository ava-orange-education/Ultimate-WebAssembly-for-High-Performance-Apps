#!/usr/bin/env bash
set -euo pipefail

if [ -z "${WASI_SDK_PATH:-}" ]; then
  echo "Please set WASI_SDK_PATH to your wasi-sdk directory (contains bin/clang)"
  echo "Example: export WASI_SDK_PATH=$HOME/wasi-sdk"
  exit 1
fi

CC="$WASI_SDK_PATH/bin/clang"
SYSROOT="$WASI_SDK_PATH/share/wasi-sysroot"

"$CC" --sysroot="$SYSROOT" -O2 -Wl,--no-entry -Wl,--export-all -o c_wasi_cli.wasm main.c
echo "Built: c_wasi_cli.wasm"
