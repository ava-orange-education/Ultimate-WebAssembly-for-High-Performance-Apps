import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { WASI } from "node:wasi";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const wasmPath = process.env.WASM_PATH
  ?? path.resolve(__dirname, "..", "rust-wasi-cli", "target", "wasm32-wasi", "release", "rust_wasi_cli.wasm");

if (!fs.existsSync(wasmPath)) {
  console.error("WASM module not found:", wasmPath);
  console.error("Build it first: cd ../rust-wasi-cli && cargo build --release --target wasm32-wasi");
  process.exit(1);
}

const wasi = new WASI({
  args: ["rust_wasi_cli.wasm", "--input", "/data/input.txt", "--output", "/data/output_node.txt"],
  env: { APP_MODE: "dev" },
  preopens: {
    "/data": path.resolve(__dirname, "..", "data"),
  },
});

const wasm = fs.readFileSync(wasmPath);
const mod = await WebAssembly.compile(wasm);
const instance = await WebAssembly.instantiate(mod, {
  wasi_snapshot_preview1: wasi.wasiImport,
});

wasi.start(instance);
console.log("Done. Check data/output_node.txt");
