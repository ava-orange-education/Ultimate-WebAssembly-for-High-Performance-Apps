CREATE TABLE IF NOT EXISTS add_inputs (
  a INT,
  b INT
);

INSERT INTO add_inputs
SELECT (random()*100)::int, (random()*100)::int
FROM generate_series(1, 1000000);

CREATE OR REPLACE FUNCTION plpgsql_add(a INT, b INT)
RETURNS INT LANGUAGE plpgsql AS $$
BEGIN
  RETURN a + b;
END;
$$;
