import mqtt from "mqtt";
import fs from "fs";
import { WASI } from "node:wasi";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const wasmPath = path.resolve(
  __dirname,
  "../wasi-sensor-filter/target/wasm32-wasi/release/sensor_filter.wasm"
);

const client = mqtt.connect("mqtt://broker.hivemq.com");

client.on("connect", () => {
  console.log("Connected to MQTT broker");
});

function loadWasm() {
  const wasm = fs.readFileSync(wasmPath);
  const wasi = new WASI({});
  return WebAssembly.instantiate(wasm, {
    wasi_snapshot_preview1: wasi.wasiImport,
  }).then(({ instance }) => instance);
}

const instance = await loadWasm();

setInterval(() => {
  const temp = +(Math.random() * 70 - 20).toFixed(1);
  const humidity = +(Math.random() * 120).toFixed(1);

  const valid = instance.exports.filter_sensor(temp, humidity);

  if (valid === 1) {
    const payload = { temp, humidity };
    client.publish("chapter9/edge/sensors", JSON.stringify(payload));
    console.log("Published:", payload);
  } else {
    console.log("Invalid data dropped");
  }
}, 4000);
