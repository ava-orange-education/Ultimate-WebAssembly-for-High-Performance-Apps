import * as ort from "onnxruntime-web";

function imageToCHWFloat32(img, size = 224) {
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(img, 0, 0, size, size);

  const { data } = ctx.getImageData(0, 0, size, size); // RGBA
  const float = new Float32Array(1 * 3 * size * size);

  const area = size * size;
  for (let i = 0; i < area; i++) {
    const r = data[i * 4 + 0] / 255;
    const g = data[i * 4 + 1] / 255;
    const b = data[i * 4 + 2] / 255;

    float[i] = r;
    float[area + i] = g;
    float[2 * area + i] = b;
  }
  return float;
}

function loadImageFromFile(file) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}

export async function classifyImageFile(file) {
  ort.env.wasm.numThreads = Math.min(4, navigator.hardwareConcurrency || 4);

  const session = await ort.InferenceSession.create("/model.onnx", {
    executionProviders: ["wasm"],
  });

  const img = await loadImageFromFile(file);
  const inputData = imageToCHWFloat32(img, 224);

  const possibleInputNames = ["input", "images", "data", "pixel_values"];
  const inputName =
    possibleInputNames.find((n) => session.inputNames.includes(n)) ??
    session.inputNames[0];

  const tensor = new ort.Tensor("float32", inputData, [1, 3, 224, 224]);
  const feeds = { [inputName]: tensor };

  const outputMap = await session.run(feeds);
  const firstOutputName = session.outputNames[0];
  const output = outputMap[firstOutputName].data;

  const scores = Array.from(output);
  const topK = 5;
  const top = scores
    .map((v, i) => ({ i, v }))
    .sort((a, b) => b.v - a.v)
    .slice(0, topK);

  return {
    inputName,
    outputName: firstOutputName,
    topK: top,
    note:
      "Indices need label mapping (e.g., ImageNet labels) to show class names.",
  };
}
