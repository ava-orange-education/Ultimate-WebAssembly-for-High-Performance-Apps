# Rust WASI CLI demo

Build:
```bash
cargo build --release --target wasm32-wasi
```

Run (from this folder):
```bash
wasmtime run --dir=./data::/data --env APP_MODE=dev   target/wasm32-wasi/release/rust_wasi_cli.wasm   --input /data/input.txt --output /data/output.txt
```

Copy sample data into this folder if needed:
- `../data/input.txt` → `./data/input.txt`
