#include <emscripten.h>

EMSCRIPTEN_KEEPALIVE
void run() {
    // Safe computation within memory limits
    int x = 100;
}
