# Rust Unit Tests in WASM (wasm-bindgen-test)

## Run in Node
```bash
wasm-pack test --node
```

## Run in headless Chrome
```bash
wasm-pack test --chrome --headless
```
