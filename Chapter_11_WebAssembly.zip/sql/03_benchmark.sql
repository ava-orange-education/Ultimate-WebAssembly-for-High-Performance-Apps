\timing on
SELECT sum(plpgsql_add(a,b)) FROM add_inputs;
