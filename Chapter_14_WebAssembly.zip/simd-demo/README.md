
# SIMD Demo (Future WASM Performance)

Demonstrates **SIMD vector operations** compiled from Rust to WebAssembly.

## Build
```
wasm-pack build --target web
```

## Run
```
cd web
npm install
npm run dev
```
