# Web Demo (Vite)

## Run
```bash
npm install
npm run dev
```

If imports fail, build the shared wasm module:
```bash
cd ../shared-wasm/rust/wasm_math
wasm-pack build --target web --release --out-dir ../../pkg --out-name wasm_math
```
