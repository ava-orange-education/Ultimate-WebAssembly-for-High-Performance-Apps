# Web Demo (Vite)

Before running this, build the wasm package:

```bash
cd ../wasm-utils
wasm-pack build --target web --dev
```

Then:

```bash
cd ../web-demo
npm install
npm run dev
```
