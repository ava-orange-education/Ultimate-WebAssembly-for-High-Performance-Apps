# AI ONNX Demo — ONNX Runtime Web (WASM)

## Setup
```bash
npm install
npm run dev
```

## Add an ONNX model
Copy your ONNX model to:
- `public/model.onnx`

This starter expects a typical image classifier input shape of `[1,3,224,224]`.
If your model differs, modify `src/onnx/classify.js`.
