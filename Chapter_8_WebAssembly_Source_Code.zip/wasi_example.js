const { WASI } = require('wasi');
const fs = require('fs');
const wasi = new WASI({ args: [], env: {}, preopens: { '/sandbox': './sandbox' } });

const wasm = await WebAssembly.compile(fs.readFileSync('./module.wasm'));
const instance = await WebAssembly.instantiate(wasm, wasi.getImportObject());
wasi.start(instance);