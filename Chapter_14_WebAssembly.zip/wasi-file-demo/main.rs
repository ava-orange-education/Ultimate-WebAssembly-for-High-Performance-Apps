
use std::fs::read_to_string;

fn main() {
    let content = read_to_string("data.txt")
        .unwrap_or_else(|_| "file not found".into());
    println!("WASI Read Result: {}", content);
}
