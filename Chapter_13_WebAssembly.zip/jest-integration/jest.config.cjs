module.exports = {
  testEnvironment: "node",
  testMatch: ["**/*.test.cjs"],
};
