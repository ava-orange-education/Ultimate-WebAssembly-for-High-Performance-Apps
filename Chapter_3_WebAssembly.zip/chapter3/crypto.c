#include <emscripten.h>

EMSCRIPTEN_KEEPALIVE
int sha256(const char* data) {
    // Simplified dummy hash function (real SHA-256 would need a library)
    int hash = 0;
    for (int i = 0; data[i]; i++) {
        hash += data[i];
    }
    return hash;
}
