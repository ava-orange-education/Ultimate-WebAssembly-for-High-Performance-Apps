import React, { useMemo, useRef, useState } from "react";
import { SafeAreaView, View, Text, Button, StyleSheet } from "react-native";
import { WebView } from "react-native-webview";

export default function App() {
  const webRef = useRef(null);
  const [msg, setMsg] = useState("Ready");

  // Local HTML that loads the wasm module (from shared-wasm/pkg)
  // NOTE: You must build the WASM first to generate wasm_math.js + wasm_math_bg.wasm.
  const html = useMemo(
    () => `
<!doctype html>
<html>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>WASM in WebView</title>
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; padding: 16px; }
    pre { white-space: pre-wrap; }
    .card { padding: 12px; border: 1px solid #ddd; border-radius: 12px; }
  </style>
</head>
<body>
  <h2>WebAssembly inside React Native WebView</h2>
  <p>This mirrors a common mobile pattern: run WASM in WebView, exchange messages with RN.</p>
  <div class="card">
    <button id="run">Run add(2,3) and fib(35)</button>
    <pre id="out">Loading...</pre>
  </div>

  <script type="module">
    async function load() {
      const out = document.getElementById('out');
      try {
        // Import from relative path baked into the zip structure when served by Expo.
        // In practice you'd bundle these into app assets; for book demos we keep it simple.
        const mod = await import('../../shared-wasm/pkg/wasm_math.js');
        await mod.default();

        const sum = mod.add(2,3);

        document.getElementById('run').onclick = () => {
          const t0 = performance.now();
          const f = mod.fib(35);
          const dt = performance.now() - t0;

          const payload = { add_2_3: sum, fib_35: f, duration_ms: dt };
          out.textContent = JSON.stringify(payload, null, 2);

          // Send result to React Native
          window.ReactNativeWebView?.postMessage(JSON.stringify(payload));
        };

        out.textContent = "Loaded. Tap the button.";
      } catch (e) {
        out.textContent = "Failed to import WASM module. Build it first.\n\n" + (e?.message ?? String(e));
      }
    }
    load();
  </script>
</body>
</html>
`,
    []
  );

  const sendPing = () => {
    webRef.current?.postMessage(JSON.stringify({ type: "ping", at: Date.now() }));
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Chapter 12 — RN + WASM (WebView)</Text>
        <Text style={styles.sub}>Latest message: {msg}</Text>
        <Button title="Send ping to WebView" onPress={sendPing} />
      </View>

      <WebView
        ref={webRef}
        originWhitelist={["*"]}
        source={{ html }}
        onMessage={(event) => setMsg(event.nativeEvent.data)}
        javaScriptEnabled
        style={styles.web}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  header: { padding: 12, borderBottomWidth: 1, borderColor: "#eee" },
  title: { fontSize: 18, fontWeight: "700" },
  sub: { marginTop: 6, marginBottom: 10, color: "#333" },
  web: { flex: 1 },
});
