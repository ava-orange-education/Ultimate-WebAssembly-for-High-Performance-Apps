# Edge CLI Demo

Run the WASI module as a pure edge workload:

```bash
wasmtime run ../wasi-sensor-filter/target/wasm32-wasi/release/sensor_filter.wasm   --invoke filter_sensor 30.0 70.0
```
