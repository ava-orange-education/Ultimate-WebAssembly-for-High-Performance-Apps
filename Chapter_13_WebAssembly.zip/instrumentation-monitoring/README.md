# Instrumentation + Monitoring Hooks (Browser)

This demo shows:
- Rust → console logs (feature flag)
- JS timing (`performance.now()`)
- error capture stub (`src/monitor.js`)

## Run
```bash
cd web
npm install
npm run dev
```
