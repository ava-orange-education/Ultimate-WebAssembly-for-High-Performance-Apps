import { classifyImageFile } from "./onnx/classify.js";

const app = document.getElementById("app");

app.innerHTML = `
  <div style="max-width: 900px; margin: 40px auto; font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;">
    <h1>ONNX Runtime Web (WASM) — Image Classification</h1>
    <p>
      Place your model at <code>public/model.onnx</code> and run inference in the browser.
      This starter assumes a common image classifier input of <code>[1, 3, 224, 224]</code>.
      If your model differs, update <code>src/onnx/classify.js</code>.
    </p>

    <div style="padding: 16px; border: 1px solid #ddd; border-radius: 10px;">
      <label>
        <strong>Select an image:</strong>
        <input id="file" type="file" accept="image/*" />
      </label>
      <div style="margin-top: 12px;">
        <button id="run">Run Inference</button>
      </div>
      <div id="status" style="margin-top: 12px; white-space: pre-wrap;"></div>
      <div style="margin-top: 12px;">
        <img id="preview" style="max-width: 360px; display: none; border-radius: 10px; border: 1px solid #eee;" />
      </div>
    </div>

    <hr style="margin: 24px 0;" />
    <details>
      <summary><strong>Notes</strong></summary>
      <ul>
        <li>Model file is not bundled. Put it at <code>ai-onnx-demo/public/model.onnx</code>.</li>
        <li>Preprocessing here is minimal; proper normalization depends on your model.</li>
        <li>If you want top-K class labels, add an ImageNet labels JSON and map indices.</li>
      </ul>
    </details>
  </div>
`;

const fileEl = document.getElementById("file");
const runBtn = document.getElementById("run");
const status = document.getElementById("status");
const preview = document.getElementById("preview");

let currentFile = null;

fileEl.addEventListener("change", (e) => {
  currentFile = e.target.files?.[0] ?? null;
  if (!currentFile) return;

  const url = URL.createObjectURL(currentFile);
  preview.src = url;
  preview.style.display = "block";
  status.textContent = "Ready. Click 'Run Inference'.";
});

runBtn.addEventListener("click", async () => {
  if (!currentFile) {
    status.textContent = "Please select an image first.";
    return;
  }
  status.textContent = "Loading model and running inference...";
  try {
    const result = await classifyImageFile(currentFile);
    status.textContent = JSON.stringify(result, null, 2);
  } catch (err) {
    status.textContent = `Error: ${err?.message ?? String(err)}`;
  }
});
