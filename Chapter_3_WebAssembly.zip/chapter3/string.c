#include <string.h>

void toUpperCase(char* ptr, int len) {
    for (int i = 0; i < len; i++) {
        if (ptr[i] >= 'a' && ptr[i] <= 'z') {
            ptr[i] -= 32;
        }
    }
}
