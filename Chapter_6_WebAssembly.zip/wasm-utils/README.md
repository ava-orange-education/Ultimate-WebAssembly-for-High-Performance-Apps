# wasm-utils (Chapter 6)

Build (dev):
```bash
wasm-pack build --target web --dev
```

Build (release):
```bash
wasm-pack build --target web --release
```
