# Chapter 13 — WebAssembly Testing, Instrumentation, and Monitoring (Runnable Demos)

This zip provides **three runnable mini-projects** aligned with Chapter 13 topics:

1) **Rust Unit Tests in WASM** using `wasm-bindgen-test`  
2) **Integration Tests (JS ↔ WASM)** using **Jest**  
3) **Instrumentation + Runtime Monitoring hooks** (timing + error capture stubs)

---

## Prerequisites

- Node.js 18+ (recommended: 20/22)
- Rust stable
- wasm-pack

Install:
```bash
rustup target add wasm32-unknown-unknown
cargo install wasm-pack
```

---

# 1) Unit Testing (Rust) — wasm-bindgen-test

Folder: `rust-unit-tests/`

Run tests in Node:
```bash
cd rust-unit-tests
wasm-pack test --node
```

(Optionally in Chrome headless)
```bash
wasm-pack test --chrome --headless
```

---

# 2) Integration Testing (Jest) — JS calls WASM

Folder: `jest-integration/`

This uses a Rust WASM package compiled for **nodejs**, then tested from Jest.

```bash
cd jest-integration
npm install
npm run build:wasm
npm test
```

---

# 3) Instrumentation + Monitoring Hooks

Folder: `instrumentation-monitoring/`

A tiny Rust WASM module:
- logs to browser console (when `feature="instrument"` is enabled)
- exposes a function that can throw (to demonstrate error capture)
- demonstrates JS wrapper timing with `performance.now()`

Run:
```bash
cd instrumentation-monitoring/web
npm install
npm run dev
```

Then open the URL Vite prints (usually http://localhost:5173).

---

## CI sample

A ready-to-copy GitHub Actions workflow is in:
- `ci-sample/github-actions.yml`
