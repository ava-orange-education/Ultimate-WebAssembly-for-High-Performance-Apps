# Shared Rust → WASM module

Build (outputs to `shared-wasm/pkg/`):
```bash
wasm-pack build --target web --release --out-dir ../../pkg --out-name wasm_math
```
