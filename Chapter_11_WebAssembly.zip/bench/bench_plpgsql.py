import psycopg2, time

conn = psycopg2.connect("host=localhost dbname=wasmdb user=postgres password=postgres")
cur = conn.cursor()

t0 = time.time()
cur.execute("SELECT sum(plpgsql_add(a,b)) FROM add_inputs")
cur.fetchone()
print("Elapsed:", time.time() - t0)
