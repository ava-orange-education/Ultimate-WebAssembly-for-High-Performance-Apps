import init, * as wasm from "../../wasm-perf/pkg/wasm_perf.js";

let ready = false;
async function ensure() {
  if (ready) return;
  await init();
  ready = true;
}

self.onmessage = async (e) => {
  await ensure();
  const { sab, start, end } = e.data;
  const view = new Float32Array(sab, start * 4, end - start);
  const sum = wasm.sum_f32_simd(view);
  self.postMessage({ start, end, sum });
};
