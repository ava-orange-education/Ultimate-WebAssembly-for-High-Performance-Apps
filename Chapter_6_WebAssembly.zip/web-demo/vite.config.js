import { defineConfig } from "vite";

// Note: wasm-pack outputs ESM for `--target web`, so Vite can import it directly.
export default defineConfig({
  server: {
    port: 5173,
  },
});
