# Chapter 12 — WebAssembly in Mobile App Development (Runnable Starter Kits)

This zip contains **two runnable projects** aligned with Chapter 12:

1) **React Native (Expo) + WebAssembly** via **WebView** (most reliable on Android/iOS today)  
2) **Web demo (Vite) using the same WASM module** (quick to run on desktop, same integration pattern)

Both projects share a **single Rust → WASM** module (`shared-wasm/rust/wasm_math`) that exports:
- `add(a, b)`
- `fib(n)` (compute-heavy enough to profile)

---

## Prerequisites

### For the Web demo (fastest)
- Node.js 18+ (recommended 20/22)
- Rust + wasm-pack (only if you want to rebuild the WASM)
  ```bash
  rustup target add wasm32-unknown-unknown
  cargo install wasm-pack
  ```

### For the React Native demo
- Node.js 18+
- Expo CLI (via `npx expo`)
- Android Studio emulator / iOS simulator / physical phone
- Rust + wasm-pack (only if you want to rebuild the WASM)

---

# 0) Build the shared WASM module (optional)

Prebuilt artifacts are already included under:
- `shared-wasm/pkg/`

If you want to rebuild:
```bash
cd shared-wasm/rust/wasm_math
wasm-pack build --target web --release --out-dir ../../pkg --out-name wasm_math
```

---

# 1) Web demo (Vite)

```bash
cd web-demo
npm install
npm run dev
```

Open the URL Vite prints.

---

# 2) React Native demo (Expo + WebView)

This demo renders a local HTML page inside a WebView, which loads the WASM module and posts results back to React Native.

```bash
cd react-native-expo-webview
npm install
npx expo start
```

Then:
- Press `a` to open Android emulator, or
- Scan the QR code with Expo Go on your phone.

> Why WebView? It gives you a stable WASM runtime on mobile today (Safari/Chrome WebView),
> avoiding JS engine differences (Hermes/JSC) for `.wasm` in pure RN JS.

---

## Folder layout

- `shared-wasm/` — Rust source + prebuilt `pkg/` output
- `web-demo/` — Vite app importing WASM directly
- `react-native-expo-webview/` — Expo app using WebView to execute WASM

