#include <emscripten.h>

EMSCRIPTEN_KEEPALIVE
void run() {
    // Dummy computation
    int result = 42;
}
