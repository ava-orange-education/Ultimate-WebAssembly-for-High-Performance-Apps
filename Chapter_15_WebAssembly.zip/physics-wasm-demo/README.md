# Physics WASM Demo

## 1) Build WASM
```bash
cd rust/physics-engine
wasm-pack build --target web --release
```

## 2) Run Web
```bash
cd ../../web
npm install
npm run dev
```
