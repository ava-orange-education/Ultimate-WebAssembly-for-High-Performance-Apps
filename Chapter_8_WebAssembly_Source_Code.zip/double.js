const fs = require('fs');
const path = require('path');

(async () => {
  const wasmBuffer = fs.readFileSync(path.resolve(__dirname, './pkg/double_mod_bg.wasm'));
  const wasmModule = await WebAssembly.instantiate(wasmBuffer);
  const { double } = wasmModule.instance.exports;
  console.log("Double of 5:", double(5)); // Output: 10
})();