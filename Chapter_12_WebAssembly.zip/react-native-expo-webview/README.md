# React Native (Expo) + WebAssembly (WebView)

## 1) Install
```bash
npm install
```

## 2) Build the shared WASM module
From the repo root:
```bash
cd ../shared-wasm/rust/wasm_math
wasm-pack build --target web --release --out-dir ../../pkg --out-name wasm_math
```

This generates:
- `shared-wasm/pkg/wasm_math.js`
- `shared-wasm/pkg/wasm_math_bg.wasm`

## 3) Run Expo
```bash
npx expo start
```

Open on:
- Android emulator / iOS simulator / physical device (Expo Go)

> Note: This demo uses an **HTML string** loaded into WebView.
> For production, you'd bundle an HTML file + wasm assets properly and reference them via `source={require(...)}`.
