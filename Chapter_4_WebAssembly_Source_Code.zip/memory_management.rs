use std::alloc::{alloc, dealloc, Layout};
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn allocate(size: usize) -> *mut u8 {
    unsafe { alloc(Layout::from_size_align(size, 8).unwrap()) }
}

#[wasm_bindgen]
pub fn deallocate(ptr: *mut u8, size: usize) {
    unsafe { dealloc(ptr, Layout::from_size_align(size, 8).unwrap()) }
}