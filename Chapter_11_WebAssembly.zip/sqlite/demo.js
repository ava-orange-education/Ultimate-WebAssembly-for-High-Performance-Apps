import Database from "better-sqlite3";

const db = new Database(":memory:");
db.exec("CREATE TABLE t(a INT, b INT)");
const ins = db.prepare("INSERT INTO t VALUES (?,?)");

for (let i=0;i<100000;i++) ins.run(i, i+1);

const rows = db.prepare("SELECT sum(a+b) as s FROM t").get();
console.log(rows);
