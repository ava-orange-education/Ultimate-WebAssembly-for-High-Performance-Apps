import init, * as wasm from "../../wasm-perf/pkg/wasm_perf.js";

/**
 * Default loads the standard wasm-pack output:
 *   wasm-perf/pkg/wasm_perf_bg.wasm
 *
 * If you run `tools/optimize.sh`, it writes:
 *   wasm-perf/pkg/wasm_perf_bg.opt.wasm
 *
 * To load the optimized wasm, uncomment the code below and ensure your server serves that file.
 */

// import { default as initOpt } from "../../wasm-perf/pkg/wasm_perf.js";

let initialized = false;

export async function loadWasm() {
  if (initialized) return wasm;
  await init();
  initialized = true;
  return wasm;
}
