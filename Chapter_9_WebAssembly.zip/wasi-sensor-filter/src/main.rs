use std::env;

#[no_mangle]
pub extern "C" fn filter_sensor(temp: f32, humidity: f32) -> i32 {
    if temp > 50.0 || temp < -20.0 || humidity < 0.0 || humidity > 100.0 {
        0 // invalid
    } else {
        1 // valid
    }
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() == 3 {
        let t: f32 = args[1].parse().unwrap_or(0.0);
        let h: f32 = args[2].parse().unwrap_or(0.0);
        let res = filter_sensor(t, h);
        println!("{}", res);
    } else {
        eprintln!("Usage: sensor_filter.wasm <temp> <humidity>");
    }
}
