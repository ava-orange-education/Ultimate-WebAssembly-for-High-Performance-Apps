# Chapter 15 — WebAssembly Real‑World Projects (Runnable Starter Kits)

This zip contains **two runnable starter projects** aligned with the Chapter 15 examples:
1) **Client‑side AI/ML inference** using **ONNX Runtime Web (WASM backend)**  
2) **Rust → WebAssembly physics module** using **wasm-bindgen**, integrated into a small web app

> Note: ML models can be large and license-specific, so the ONNX model file is **not bundled**.
> The README shows exactly where to place a model and how to run.

---

## Prerequisites

- **Node.js 18+** (recommended: 20/22)
- **npm** (comes with Node)
- For the Rust/Wasm demo:
  - **Rust stable** + `wasm32-unknown-unknown` target
  - **wasm-pack**
  - Optional: `binaryen` for `wasm-opt` (nice-to-have)

Quick install hints:
- Rust: https://rustup.rs
- wasm-pack: `cargo install wasm-pack`
- wasm target: `rustup target add wasm32-unknown-unknown`

---

# 1) AI/ML Demo — ONNX Runtime Web (WASM)

Folder: `ai-onnx-demo/`

### Install & Run
```bash
cd ai-onnx-demo
npm install
npm run dev
```

Open the URL Vite prints (usually `http://localhost:5173`).

### Add a Model
Put your ONNX model file here:

- `ai-onnx-demo/public/model.onnx`

The demo is written to expect an **image classification** style model and includes a *basic* preprocessing step.
If your model has different inputs (e.g., BERT), adjust `src/onnx/classify.js`.

---

# 2) Physics Demo — Rust + wasm-bindgen

Folder: `physics-wasm-demo/`

This demo builds a small Rust module (`rust/physics-engine`) into WebAssembly and then runs a Vite web app (`web/`)
that calls it from JavaScript.

## Build the WASM package
```bash
cd physics-wasm-demo/rust/physics-engine
wasm-pack build --target web --release
```

This creates `pkg/` which the web app imports.

## Run the web app
```bash
cd ../../web
npm install
npm run dev
```

Open the URL Vite prints.

---

## Troubleshooting

### `wasm-pack: command not found`
```bash
cargo install wasm-pack
```

### Rust target missing
```bash
rustup target add wasm32-unknown-unknown
```

### CORS / local file issues
Always run via `npm run dev` (Vite dev server), not by opening HTML directly.
