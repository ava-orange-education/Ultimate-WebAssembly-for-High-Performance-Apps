import { loadWasm } from "./wasmLoader.js";

const out = document.getElementById("out");
const lenEl = document.getElementById("len");
const itersEl = document.getElementById("iters");

function log(obj) {
  out.textContent += (typeof obj === "string" ? obj : JSON.stringify(obj, null, 2)) + "\n";
}

function hr() {
  out.textContent += "\n" + "-".repeat(60) + "\n";
}

function getParams() {
  const n = Math.max(1, parseInt(lenEl.value || "1000000", 10));
  const iters = Math.max(1, parseInt(itersEl.value || "10", 10));
  return { n, iters };
}

function makeF32(n) {
  const a = new Float32Array(n);
  for (let i = 0; i < n; i++) a[i] = (i % 1000) * 0.001;
  return a;
}

function bench(fn, iters) {
  // warm-up
  fn();
  const t0 = performance.now();
  let res;
  for (let i = 0; i < iters; i++) res = fn();
  const t1 = performance.now();
  return { elapsed_ms: +(t1 - t0).toFixed(2), last: res };
}

document.getElementById("btn-init").onclick = async () => {
  out.textContent = "";
  const wasm = await loadWasm();
  log("Wasm initialized ✅");
  log(Object.keys(wasm).filter(k => typeof wasm[k] === "function").sort());
};

document.getElementById("btn-simd").onclick = async () => {
  out.textContent = "";
  const wasm = await loadWasm();
  const { n, iters } = getParams();
  const arr = makeF32(n);

  log({ test: "scalar_vs_simd_sum", n, iters });

  const scalar = bench(() => wasm.sum_f32_scalar(arr), iters);
  const simd = bench(() => wasm.sum_f32_simd(arr), iters);

  log({ scalar, simd, speedup_x: +(scalar.elapsed_ms / simd.elapsed_ms).toFixed(2) });
  hr();
  log("Tip: Try different n/iters. SIMD may help more on larger arrays.");
};

document.getElementById("btn-boundary").onclick = async () => {
  out.textContent = "";
  const wasm = await loadWasm();
  const { n, iters } = getParams();
  const a = makeF32(n);

  log({ test: "boundary_overhead", n, iters });

  // Worst pattern: call wasm per element (simulated by slicing tiny views)
  const perElement = bench(() => {
    let s = 0;
    for (let i = 0; i < a.length; i++) {
      // per-call overhead dominates
      const tmp = new Float32Array([a[i]]);
      wasm.scale_in_place(tmp, 1.000001);
      s += tmp[0];
    }
    return s;
  }, 1); // doing this multiple times is too slow

  // Best pattern: batch
  const batched = bench(() => {
    const b = a.slice();
    wasm.scale_in_place(b, 1.000001);
    return wasm.sum_f32_scalar(b);
  }, iters);

  log({ per_element_elapsed_ms: perElement.elapsed_ms, batched });
  hr();
  log("Expected: batched is dramatically faster because JS↔Wasm crossing is minimized.");
};

document.getElementById("btn-workers").onclick = async () => {
  out.textContent = "";
  const wasm = await loadWasm();
  const { n } = getParams();
  const cpu = navigator.hardwareConcurrency || 4;
  const workers = Math.max(2, Math.min(8, cpu));
  log({ test: "workers_sharedarraybuffer", n, workers });

  // Shared buffer with float32 data
  const sab = new SharedArrayBuffer(n * 4);
  const view = new Float32Array(sab);
  for (let i = 0; i < n; i++) view[i] = (i % 1000) * 0.001;

  const perWorker = Math.ceil(n / workers);
  const workerUrl = new URL("./worker.js", import.meta.url);

  const promises = [];
  const t0 = performance.now();

  for (let w = 0; w < workers; w++) {
    const start = w * perWorker;
    const end = Math.min(n, start + perWorker);
    const worker = new Worker(workerUrl, { type: "module" });
    promises.push(new Promise((resolve, reject) => {
      worker.onmessage = (e) => { worker.terminate(); resolve(e.data); };
      worker.onerror = (e) => { worker.terminate(); reject(e); };
      worker.postMessage({ sab, start, end });
    }));
  }

  const partials = await Promise.all(promises);
  const total = partials.reduce((a, b) => a + b.sum, 0);
  const t1 = performance.now();

  log({ total_sum: total, elapsed_ms: +(t1 - t0).toFixed(2), partials });
  hr();
  log("Note: Each worker loads Wasm; real apps may pool workers or use module caching.");
};
