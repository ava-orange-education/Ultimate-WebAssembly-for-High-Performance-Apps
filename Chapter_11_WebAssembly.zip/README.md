# Chapter 11 – WebAssembly in Databases (Executable Code Kit)

This project is a **clean, runnable extraction** from Chapter 11
("WebAssembly in Databases") fileciteturn6file0.

It demonstrates:
- Rust → WebAssembly (WASI) compilation
- PostgreSQL UDF pattern (conceptual + runnable baseline)
- SQLite embedded processing pattern
- Database-side benchmarking

---

## Prerequisites

- Rust (stable)
- Wasmtime
- Docker
- Node.js 18+
- Python 3.10+

```bash
rustup target add wasm32-wasi
curl https://wasmtime.dev/install.sh -sSf | bash
```

---

## 1️⃣ Build the WASM module

```bash
cd wasm
rustc --target wasm32-wasi rust_add.rs -O -o rust_add.wasm
```

Test:
```bash
echo '{"a":2,"b":3}' | wasmtime run rust_add.wasm
```

---

## 2️⃣ PostgreSQL demo (PL/pgSQL + Wasm concept)

```bash
cd postgres
docker compose up -d
```

Connect:
```bash
docker exec -it chapter11-postgres psql -U postgres -d wasmdb
```

Run:
```sql
\i /sql/01_setup.sql
\i /sql/03_benchmark.sql
```

> The `LANGUAGE wasm` example in `02_wasm_udf.sql` is **conceptual** and
> requires pg-wasm or a custom PostgreSQL build.

---

## 3️⃣ SQLite demo (Node.js)

```bash
cd sqlite
npm install
node demo.js
```

---

## 4️⃣ Python benchmark (baseline comparison)

```bash
cd bench
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python bench_plpgsql.py
```

---

## Folder Structure

```
chapter11_executable/
├── wasm/            # Rust → WASM module
├── sql/             # SQL files from Chapter 11
├── postgres/        # Dockerized PostgreSQL
├── sqlite/          # SQLite + WASM processing
├── bench/           # Benchmark scripts
└── README.md
```

---

## Notes

- PostgreSQL does **not** ship with native Wasm UDFs yet.
- Chapter examples are faithful to the book while keeping this kit runnable.
- Same WASM logic can be reused across PostgreSQL, SQLite, and ScyllaDB-style pipelines.

---

## Cleanup

```bash
cd postgres
docker compose down -v
```
