# Chapter 5 — Optimizing WebAssembly Performance (Executable Code Kit)

This kit converts Chapter 5’s topics (memory model, JS↔Wasm I/O batching, wasm-opt, SIMD, Web Workers + SharedArrayBuffer, benchmarking) into **runnable demos**. fileciteturn10file0

## What’s inside
1) **wasm-perf/** (Rust + wasm-bindgen)
   - Scalar vs SIMD sum (`sum_f32_scalar`, `sum_f32_simd`)
   - Batch processing entrypoints to reduce JS↔Wasm boundary overhead
   - Simple image “grayscale” loop for profiling
2) **web-demo/** (Vite)
   - Bench UI (throughput + latency)
   - “Boundary overhead” demo: per-element vs batched call
   - Worker demo using SharedArrayBuffer (JS parallelism; each worker calls Wasm)
3) **tools/**
   - `optimize.sh` runs `wasm-opt` and produces size report + (optional) Brotli

---

## Prerequisites
- Rust stable
- wasm-pack
- Node.js 18+
- (Optional but recommended) Binaryen (`wasm-opt`)
- (Optional) Brotli (`brotli` CLI)

### Install
```bash
cargo install wasm-pack
```

Binaryen:
- macOS: `brew install binaryen`
- Ubuntu: `sudo apt-get install -y binaryen`
- Windows: download Binaryen release zip and add to PATH

Brotli:
- macOS: `brew install brotli`
- Ubuntu: `sudo apt-get install -y brotli`

---

# 1) Build the Wasm package

```bash
cd wasm-perf
wasm-pack build --target web --release
```

This produces `wasm-perf/pkg/`.

---

# 2) Run the web demo

```bash
cd ../web-demo
npm install
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173).

---

# 3) Run wasm-opt (size + speed)

After building release:
```bash
cd ../tools
./optimize.sh
```

Outputs:
- optimized `.wasm` under `wasm-perf/pkg/` as `wasm_perf_bg.opt.wasm`
- size summary in terminal
- optional `.br` if brotli is installed

> You can swap the demo to use the optimized wasm by editing `web-demo/src/wasmLoader.js`
> (instructions inside that file).

---

# Notes
- The SIMD demo uses WebAssembly SIMD (`simd128`). Most modern browsers support it, but if a browser
  disables SIMD, the demo falls back to scalar.
- Web Worker parallelism here is demonstrated at the **JS level** (SharedArrayBuffer + workers).
  True Wasm threads require special toolchain flags and cross-origin isolation; this kit keeps it simple.

---

## Cleanup
Just stop Vite (`Ctrl+C`). Build artifacts are under `wasm-perf/pkg` and `wasm-perf/target`.
