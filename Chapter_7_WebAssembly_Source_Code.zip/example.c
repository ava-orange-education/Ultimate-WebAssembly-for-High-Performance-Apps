
#include <stdio.h>

int main() {
    printf("Hello, WebAssembly!\n");
    return 0;
}
