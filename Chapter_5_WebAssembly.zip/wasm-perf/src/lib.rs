use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn sum_f32_scalar(values: &[f32]) -> f32 {
    values.iter().copied().sum()
}

// SIMD path (simd128). Will be used if the browser/runtime supports it.
#[wasm_bindgen]
pub fn sum_f32_simd(values: &[f32]) -> f32 {
    sum_f32_simd_impl(values)
}

#[cfg(all(target_arch = "wasm32", target_feature = "simd128"))]
fn sum_f32_simd_impl(values: &[f32]) -> f32 {
    use core::arch::wasm32::*;

    let mut acc = f32x4_splat(0.0);
    let mut i = 0usize;

    // process 4 at a time
    while i + 4 <= values.len() {
        // Safe because we only read within bounds; alignment isn't required for wasm32 loads
        let ptr = values.as_ptr().wrapping_add(i) as *const v128;
        let v = unsafe { v128_load(ptr) };
        acc = f32x4_add(acc, v);
        i += 4;
    }

    // horizontal add
    let lanes = unsafe { core::mem::transmute::<v128, [f32; 4]>(acc) };
    let mut sum = lanes[0] + lanes[1] + lanes[2] + lanes[3];

    // tail
    while i < values.len() {
        sum += values[i];
        i += 1;
    }
    sum
}

#[cfg(not(all(target_arch = "wasm32", target_feature = "simd128")))]
fn sum_f32_simd_impl(values: &[f32]) -> f32 {
    // Fallback to scalar if SIMD is not enabled/available
    sum_f32_scalar(values)
}

/// Demonstrates boundary overhead: calling into Wasm per-element vs batching.
/// This function scales an f32 slice in-place.
#[wasm_bindgen]
pub fn scale_in_place(values: &mut [f32], factor: f32) {
    for v in values.iter_mut() {
        *v *= factor;
    }
}

/// Simple “image loop” for profiling: grayscale RGBA buffer in-place.
/// `rgba` length must be multiple of 4.
#[wasm_bindgen]
pub fn grayscale_rgba_in_place(rgba: &mut [u8]) {
    let mut i = 0usize;
    while i + 3 < rgba.len() {
        let r = rgba[i] as f32;
        let g = rgba[i + 1] as f32;
        let b = rgba[i + 2] as f32;
        let gray = (0.3 * r + 0.59 * g + 0.11 * b) as u8;
        rgba[i] = gray;
        rgba[i + 1] = gray;
        rgba[i + 2] = gray;
        // alpha rgba[i+3] unchanged
        i += 4;
    }
}
