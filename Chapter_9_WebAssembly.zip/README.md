# Chapter 9 — WebAssembly for Edge Computing & IoT (Executable Kit)

This ZIP contains **runnable, end-to-end examples** derived from Chapter 9:
* Edge execution with WebAssembly (WASI)
* IoT-style sensor filtering
* MQTT gateway integration
* Edge/serverless-style execution model

The goal is to turn the **conceptual examples** in the chapter into
**locally executable demos** you can run on a laptop, Raspberry Pi, or edge VM.

---

## Contents

1. `wasi-sensor-filter/`  
   Rust → WASI module that filters temperature & humidity readings

2. `mqtt-gateway-node/`  
   Node.js IoT gateway that:
   - loads the WASI module
   - filters sensor data locally
   - publishes valid readings to MQTT

3. `edge-cli-demo/`  
   Simple CLI-style edge workload using Wasmtime (no MQTT)

4. `data/`  
   Simulated sensor inputs

---

## Prerequisites

- Rust (stable)
- Wasmtime
- Node.js 18+
- Internet access (for public MQTT broker)

Install Wasmtime:
```bash
curl https://wasmtime.dev/install.sh -sSf | bash
```

Add WASI target:
```bash
rustup target add wasm32-wasi
```

---

## 1️⃣ Build the WASI sensor filter

```bash
cd wasi-sensor-filter
cargo build --release --target wasm32-wasi
```

This produces:
```
target/wasm32-wasi/release/sensor_filter.wasm
```

---

## 2️⃣ Run as a standalone edge workload

```bash
cd edge-cli-demo
wasmtime run   ../wasi-sensor-filter/target/wasm32-wasi/release/sensor_filter.wasm   --invoke filter_sensor 25.5 62.0
```

Expected output:
```
1   # valid reading
```

---

## 3️⃣ Run IoT gateway with MQTT (edge-style)

```bash
cd mqtt-gateway-node
npm install
node gateway.js
```

What happens:
- Random sensor readings are generated
- WASI module filters invalid data
- Valid readings are published to MQTT topic:
  `chapter9/edge/sensors`

You should see logs like:
```
Published: { temp: 24.3, humidity: 61.2 }
Invalid data dropped
```

---

## 4️⃣ Subscribe to MQTT topic (optional)

In another terminal:
```bash
npm install -g mqtt
mqtt sub -t chapter9/edge/sensors -h broker.hivemq.com
```

---

## Notes

- This mirrors **Section 9.9 (Practical IoT + MQTT example)** from the chapter.
- The same WASM module can run:
  - locally (Wasmtime)
  - on Raspberry Pi
  - inside edge gateways
- Security is enforced via WASI sandboxing (no filesystem/network unless granted).

---

## Cleanup

Just stop Node.js (`Ctrl+C`). No services are persisted.
