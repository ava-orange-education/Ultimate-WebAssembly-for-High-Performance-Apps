use std::{env, fs, io::Write, time::{SystemTime, UNIX_EPOCH}};

fn usage() {
    eprintln!("Usage: rust_wasi_cli.wasm --input <path> --output <path>");
}

fn main() {
    let mut args = env::args().collect::<Vec<_>>();
    // args[0] is module name
    if args.len() < 5 {
        usage();
        std::process::exit(2);
    }

    let mut input: Option<String> = None;
    let mut output: Option<String> = None;

    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--input" => { i += 1; if i < args.len() { input = Some(args[i].clone()); } }
            "--output" => { i += 1; if i < args.len() { output = Some(args[i].clone()); } }
            _ => {}
        }
        i += 1;
    }

    let input = input.unwrap_or_else(|| { usage(); std::process::exit(2) });
    let output = output.unwrap_or_else(|| { usage(); std::process::exit(2) });

    // Args + env
    println!("Args: {:?}", env::args().collect::<Vec<_>>());
    println!("APP_MODE: {:?}", env::var("APP_MODE").ok());

    // Clock
    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap();
    println!("unix_ms: {}", now.as_millis());

    // Randomness (best-effort)
    // In WASI, secure randomness is typically provided by the host runtime.
    let mut rnd = [0u8; 16];
    getrandom(&mut rnd);
    println!("random_16_bytes_hex: {}", to_hex(&rnd));

    // File I/O
    let content = fs::read_to_string(&input).expect("read input");
    let normalized = content.to_uppercase();

    let mut f = fs::File::create(&output).expect("create output");
    writeln!(f, "WASI DEMO OUTPUT").ok();
    writeln!(f, "INPUT_BYTES={}", content.as_bytes().len()).ok();
    writeln!(f, "UPPERCASED:
{}", normalized).ok();

    println!("Wrote output to: {}", output);
}

// Minimal random filler using a time-based xor (demo only).
// For cryptographic uses, rely on runtime-provided randomness.
// This exists to keep the demo dependency-free.
fn getrandom(buf: &mut [u8]) {
    let mut seed = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_nanos() as u64;

    for b in buf.iter_mut() {
        // xorshift64*
        seed ^= seed >> 12;
        seed ^= seed << 25;
        seed ^= seed >> 27;
        seed = seed.wrapping_mul(0x2545F4914F6CDD1D);
        *b = (seed & 0xFF) as u8;
    }
}

fn to_hex(bytes: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut s = String::with_capacity(bytes.len() * 2);
    for &b in bytes {
        s.push(HEX[(b >> 4) as usize] as char);
        s.push(HEX[(b & 0x0F) as usize] as char);
    }
    s
}
