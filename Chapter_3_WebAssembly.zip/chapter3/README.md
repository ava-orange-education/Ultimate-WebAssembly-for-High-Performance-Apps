# Chapter 3: Executing WebAssembly in the Browser

## Setup Instructions
1. Install Emscripten: Follow https://emscripten.org/docs/getting_started/downloads.html
2. Compile C files to Wasm:
   - emcc math.c -s EXPORTED_FUNCTIONS='["_add", "_multiply"]' -s EXPORTED_RUNTIME_METHODS='["ccall"]' -o math.wasm
   - emcc crypto.c -s EXPORTED_FUNCTIONS='["_sha256"]' -o crypto.wasm
   - emcc compute.c -s EXPORTED_FUNCTIONS='["_run"]' -o compute.wasm
   - emcc string.c -s EXPORTED_FUNCTIONS='["_toUpperCase"]' -s EXPORT_ALL=1 -o string.wasm
   - emcc safe.c -s EXPORTED_FUNCTIONS='["_run"]' -o safe.wasm
   - emcc matrix.c -s EXPORTED_FUNCTIONS='["_multiply"]' -s EXPORT_ALL=1 -o matrix.wasm
3. Serve files locally:
   - Use a simple server like `python -m http.server` or `npx serve`
4. Open `index.html` in a browser and click "Run All Examples".
