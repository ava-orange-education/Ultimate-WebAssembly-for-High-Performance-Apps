# Rust Physics Engine (wasm-bindgen)

Build:
```bash
wasm-pack build --target web --release
```

This creates `pkg/` which the web app imports.
