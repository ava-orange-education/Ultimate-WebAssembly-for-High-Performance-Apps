use wasm_bindgen::prelude::*;
use web_sys::console;

#[wasm_bindgen]
pub fn add(a: i32, b: i32) -> i32 {
    a + b
}

#[wasm_bindgen]
pub fn reverse_string(input: &str) -> String {
    input.chars().rev().collect()
}

#[wasm_bindgen]
pub fn capitalize(input: &str) -> String {
    input
        .chars()
        .enumerate()
        .map(|(i, c)| if i == 0 { c.to_ascii_uppercase() } else { c })
        .collect()
}

#[wasm_bindgen]
pub struct Point {
    x: f32,
    y: f32,
}

#[wasm_bindgen]
impl Point {
    #[wasm_bindgen(constructor)]
    pub fn new(x: f32, y: f32) -> Point {
        Point { x, y }
    }

    pub fn distance(&self, other: &Point) -> f32 {
        ((self.x - other.x).powi(2) + (self.y - other.y).powi(2)).sqrt()
    }

    pub fn x(&self) -> f32 { self.x }
    pub fn y(&self) -> f32 { self.y }
}

#[wasm_bindgen]
pub fn sum(values: &[i32]) -> i32 {
    values.iter().sum()
}

#[derive(serde::Serialize)]
struct User {
    id: u32,
    name: String,
}

#[wasm_bindgen]
pub fn get_user() -> JsValue {
    // Safer than deprecated JsValue::from_serde
    serde_wasm_bindgen::to_value(&User { id: 1, name: "Alice".into() })
        .expect("serialize user")
}

#[wasm_bindgen]
pub fn log_data(val: i32) {
    console::log_1(&format!("Logging value from Rust/Wasm: {}", val).into());
}
